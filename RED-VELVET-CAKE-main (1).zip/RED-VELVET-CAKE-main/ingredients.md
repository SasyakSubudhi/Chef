Red Velvet Cake:
2 cups plus 2 tablespoons (250 grams) cake flour

1/2 teaspoon (2 grams) salt

2 tablespoons (15 grams) regular unsweetened or Dutch-processed unsweetened cocoa powder

1/2 cup (113 grams) unsalted butter, at room temperature

1 1/2 cups (300 grams) granulated white sugar

2 large (100 grams) eggs, at room temperature

1 teaspoon (4 grams) pure vanilla extract

1 cup (240 ml) buttermilk, at room temperature

2 tablespoons (22 grams) liquid red food coloring (I use McCormick's brand)

1 teaspoon (4 grams) white distilled vinegar

1 teaspoon (4 grams) baking soda

Cream Cheese Frosting:

8 ounces (227 grams) cream cheese, at room temperature

8 ounces (227 grams) Mascarpone cheese, at room temperature

1 teaspoon (4 grams) pure vanilla extract

1 cup (115 grams) confectioners' (icing or powdered) sugar, sifted

1 1/4 cups (300 ml) cold heavy whipping cream (cream with a 35-40% butterfat content)



